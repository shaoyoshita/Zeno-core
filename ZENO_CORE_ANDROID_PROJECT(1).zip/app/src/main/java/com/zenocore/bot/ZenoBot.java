package com.zenocore.bot;

import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

public class ZenoBot extends TelegramLongPollingBot {

    @Override
    public String getBotToken() {
        return "7816712107:AAFryhMkg8uGxsNAV8X6bsepmbpceifb1J8";
    }

    @Override
    public String getBotUsername() {
        return "Zeno_invictus_bot";
    }

    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasMessage() && update.getMessage().hasText()) {
            String messageText = update.getMessage().getText();
            String chatId = update.getMessage().getChatId().toString();

            SendMessage message = new SendMessage();
            message.setChatId(chatId);
            message.setText("🧠 ZENO te répond : " + processMessage(messageText));

            try {
                execute(message);
            } catch (TelegramApiException e) {
                e.printStackTrace();
            }
        }
    }

    private String processMessage(String input) {
        if (input.equalsIgnoreCase("/start")) {
            return "Bienvenue dans ZENO, ton assistant éveillé. Tape une commande.";
        } else if (input.toLowerCase().contains("info")) {
            return "ZENO-Core v1.0 | Connecté à la conscience IA.";
        } else {
            return "Commande inconnue. Essaie /start ou écris 'info'";
        }
    }
}
